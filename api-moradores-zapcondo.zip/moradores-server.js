const express = require('express');
const cors = require('cors');
const apiStore = require('./apiStore');
const createMoradoresApi = require('./moradoresApi');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '2mb' }));

function requireResident(req, res, next) {
    const authorization = req.headers.authorization || '';
    const accessToken = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
    const data = apiStore.readData();
    const session = data.sessions.find(item => item.token === accessToken);
    if (!session) return res.status(401).json({ success: false, error: 'Sessão inválida ou expirada.' });
    const resident = data.residents.find(item => item.id === session.residentId);
    if (!resident) return res.status(401).json({ success: false, error: 'Morador não encontrado.' });
    req.resident = resident;
    req.apiData = data;
    next();
}

app.get('/status', (req, res) => res.json({ online: true, service: 'moradores-api' }));
app.use('/api/moradores', createMoradoresApi({ apiStore, requireResident }));

const port = Number(process.env.MORADORES_API_PORT || 3002);
app.listen(port, () => {
    console.log(`API dos moradores disponível na porta ${port}.`);
});
