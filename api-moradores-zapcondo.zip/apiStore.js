const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = path.join(__dirname, 'data', 'api-data.json');

const EMPTY_DATA = {
    residents: [],
    sessions: [],
    parcels: [],
    notifications: [],
    reservations: []
};

function ensureDataFile() {
    const directory = path.dirname(DATA_FILE);
    if (!fs.existsSync(directory)) fs.mkdirSync(directory, { recursive: true });
    if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify(EMPTY_DATA, null, 2));
}

function readData() {
    ensureDataFile();
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return { ...EMPTY_DATA, ...parsed };
}

function writeData(data) {
    ensureDataFile();
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function id(prefix) {
    return `${prefix}_${crypto.randomUUID()}`;
}

function token() {
    return crypto.randomBytes(32).toString('hex');
}

module.exports = {
    readData,
    writeData,
    id,
    token
};
